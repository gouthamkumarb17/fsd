# BhashaBuddy v2 (VoiceBridge Jam)
English / Telugu / Hindi / Tamil technical-vocabulary app. Vanilla HTML, CSS, JavaScript front end plus a small Node.js back end. No npm install needed (zero dependencies, Node 20+).

## Run
    npm start            # http://localhost:3000 (use Chrome/Edge for speech)
    npm test             # node:test suite: scoring, streaks, merge, validation, HTTP API

## Structure
- index.html, css/styles.css            shell and styles
- js/data.js       UI strings + vocabulary (also loaded by the server: single source of truth)
- js/storage.js    localStorage profile, daily goal, streak, mergeProfile
- js/speech.js     TTS, SpeechRecognition, Levenshtein scoring
- js/api.js        loads words and syncs profile/scores; falls back to local data when offline
- js/app.js        views and render loop
- server/server.js static server + REST API (/api/words, /api/profile/:id, /api/scores), data in server/db.json
- tests/app.test.js
- sw.js            offline cache (network-first for /api)

## What changed after evaluation
- Back end added (words, profiles, best pronunciation scores) with strict input validation, body size limit, CSP and nosniff headers, path-traversal protection.
- Front end now fetches words from the API, keeps local fallback, and syncs progress without losing offline work.
- Automated tests for the Levenshtein scoring, streak/state transitions, validation and API.
- Typed input is sanitised; server text is HTML-escaped before rendering; quiz regex is escaped.
