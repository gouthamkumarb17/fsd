// Offline: app shell cached on install. /api/* is network-first (fresh data online, cached copy offline); everything else cache-first.
const C='bb-v2',F=['./','index.html','css/styles.css','js/data.js','js/storage.js','js/speech.js','js/api.js','js/app.js'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(F))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==C).map(k=>caches.delete(k))))));
const net=r=>fetch(r).then(res=>{const cp=res.clone();caches.open(C).then(c=>c.put(r,cp));return res});
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  const api=new URL(e.request.url).pathname.startsWith('/api/');
  e.respondWith(api?net(e.request).catch(()=>caches.match(e.request)):caches.match(e.request).then(r=>r||net(e.request)));
});
