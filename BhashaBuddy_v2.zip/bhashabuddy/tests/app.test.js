process.env.DB_FILE=require('os').tmpdir()+'/bb-test-'+process.pid+'.json';
const test=require('node:test'),assert=require('node:assert/strict');
const {lev,score}=require('../js/speech.js');
const st=require('../js/storage.js'),S=st.S;
const {server,validProfile,validScore}=require('../server/server.js');
const {WORDS}=require('../js/data.js');

test('levenshtein distance',()=>{
  assert.equal(lev('kitten','sitting'),3);assert.equal(lev('','abc'),3);assert.equal(lev('same','same'),0);
});
test('pronunciation score',()=>{
  assert.equal(score('Algorithm','algorithm'),100);
  assert.ok(score('algoritm','algorithm')>=80,'one-letter slip is forgiven');
  assert.ok(score('banana','algorithm')<50);
  assert.equal(score('','algorithm'),0);
});
function reset(goal=3){Object.assign(S,{done:[],mastered:[],streak:0,last:'',goal})}
test('streak starts when daily goal is reached, once',()=>{
  reset();st.credit(1);st.credit(2);assert.equal(S.streak,0);
  st.credit(2);st.credit(3);assert.equal(S.streak,1);assert.equal(S.done.length,3);
});
test('streak continues after yesterday, resets after a gap',()=>{
  reset();S.last=st.dayStr(1);S.streak=4;[1,2,3].forEach(st.credit);assert.equal(S.streak,5);
  reset();S.last=st.dayStr(3);S.streak=4;[1,2,3].forEach(st.credit);assert.equal(S.streak,1);
});
test('mergeProfile keeps the union of progress',()=>{
  reset();S.mastered=[1];st.mergeProfile({day:S.day,done:[2],mastered:[2,3],streak:2,last:st.dayStr(1)});
  assert.deepEqual(S.mastered.sort(),[1,2,3]);assert.equal(S.streak,2);
});
test('server validation',()=>{
  const ok={lang:'te',goal:5,day:'2026-11-20',done:[1],mastered:[1,2],streak:3,last:'2026-11-19'};
  assert.ok(validProfile(ok));
  assert.ok(!validProfile({...ok,lang:'xx'}));assert.ok(!validProfile({...ok,goal:7}));
  assert.ok(!validProfile({...ok,done:[999]}));assert.ok(!validProfile({...ok,day:'<script>'}));
  assert.ok(validScore({userId:'user-12345',wordId:0,score:90}));
  assert.ok(!validScore({userId:'../etc',wordId:0,score:90}));assert.ok(!validScore({userId:'user-12345',wordId:0,score:101}));
});
test('HTTP API and static serving',async t=>{
  const srv=server();await new Promise(r=>srv.listen(0,r));
  t.after(()=>{srv.closeAllConnections();srv.close()});
  const base='http://localhost:'+srv.address().port,J={'Content-Type':'application/json'},id='test-user-1234';
  assert.equal((await (await fetch(base+'/api/words')).json()).length,WORDS.length);
  assert.equal((await fetch(base+'/api/profile/'+id,{method:'PUT',headers:J,body:JSON.stringify({lang:'xx'})})).status,400);
  const prof={lang:'hi',goal:5,day:'2026-11-20',done:[],mastered:[4],streak:1,last:'2026-11-20'};
  assert.equal((await fetch(base+'/api/profile/'+id,{method:'PUT',headers:J,body:JSON.stringify(prof)})).status,200);
  assert.deepEqual(await (await fetch(base+'/api/profile/'+id)).json(),prof);
  const sc=s=>fetch(base+'/api/scores',{method:'POST',headers:J,body:JSON.stringify({userId:id,wordId:0,score:s})}).then(r=>r.json());
  assert.equal((await sc(80)).best,80);assert.equal((await sc(60)).best,80);
  const home=await fetch(base+'/');assert.equal(home.status,200);assert.equal(home.headers.get('x-content-type-options'),'nosniff');
  assert.equal((await fetch(base+'/server/server.js')).status,404);
});
