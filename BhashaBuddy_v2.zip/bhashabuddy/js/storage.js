// ===== Persistence: localStorage profile, daily goal, streak, mastered words =====
const KEY='bhashabuddy.v1';
const dayStr=(off=0)=>new Date(Date.now()-off*864e5).toISOString().slice(0,10);
function load(){
  let s={};try{s=JSON.parse(localStorage.getItem(KEY))||{}}catch(e){}
  s=Object.assign({lang:'en',goal:5,day:'',done:[],mastered:[],streak:0,last:''},s);
  if(s.day!==dayStr()){s.day=dayStr();s.done=[]}   // new day resets the daily list
  return s;
}
const S=load();
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}if(typeof pushProfile==='function')pushProfile()}
function credit(id){                                 // a word counts when pronounced or quizzed correctly
  if(!S.done.includes(id))S.done.push(id);
  if(!S.mastered.includes(id))S.mastered.push(id);
  if(S.done.length===S.goal){S.streak=S.last===dayStr(1)?S.streak+1:1;S.last=dayStr()}
  save();
}
function mergeProfile(p){                          // combine server profile with local one, never losing progress
  if(!p)return;
  S.mastered=[...new Set([...S.mastered,...(p.mastered||[])])];
  if(p.day===S.day)S.done=[...new Set([...S.done,...(p.done||[])])];
  if((p.last||'')>S.last){S.last=p.last;S.streak=p.streak}else if(p.last===S.last)S.streak=Math.max(S.streak,p.streak);
  save();
}
if(typeof module!=='undefined')module.exports={load,S,credit,dayStr,mergeProfile};
