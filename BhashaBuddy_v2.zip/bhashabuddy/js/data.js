// ===== Data layer: UI strings + vocabulary. Add words by appending rows to RAW. =====
const LANGS=[['en','EN'],['te','తె'],['hi','हि'],['ta','த']];
const UNITS=['Computing','Tools','Core science','Placement'];
const I18N={
en:{learn:'Learn',quiz:'Quiz',progress:'Progress',listen:'Listen',speak:'Speak',next:'Next',prev:'Back',goal:"Today's goal",streak:'Day streak',mastered:'Words mastered',match:'Pronunciation Match',great:'Excellent! Clear pronunciation.',retry:'Close. Listen again and try once more.',nospeech:"Voice input isn't supported here. Type the word instead.",check:'Check',type:'Type the word',correct:'Correct!',wrong:'Not quite. Answer:',pick:'Pick the meaning of',fill:'Fill in the blank',score:'Score',start:'Start quiz',again:'New quiz',listening:'Listening…',example:'Example',done:'Daily goal reached!',unit:'Unit',target:'Words per day'},
te:{learn:'నేర్చుకో',quiz:'క్విజ్',progress:'పురోగతి',listen:'వినండి',speak:'మాట్లాడండి',next:'తరువాత',prev:'వెనుకకు',goal:'నేటి లక్ష్యం',streak:'రోజుల వరుస',mastered:'నేర్చుకున్న పదాలు',match:'ఉచ్చారణ సరిపోలిక',great:'అద్భుతం! ఉచ్చారణ స్పష్టంగా ఉంది.',retry:'దాదాపు సరిగ్గా ఉంది. మళ్లీ విని ప్రయత్నించండి.',nospeech:'ఈ బ్రౌజర్‌లో వాయిస్ ఇన్‌పుట్ లేదు. పదాన్ని టైప్ చేయండి.',check:'తనిఖీ',type:'పదాన్ని టైప్ చేయండి',correct:'సరైనది!',wrong:'సరికాదు. సమాధానం:',pick:'అర్థం ఎంచుకోండి:',fill:'ఖాళీని పూరించండి',score:'స్కోరు',start:'క్విజ్ ప్రారంభించు',again:'కొత్త క్విజ్',listening:'వింటున్నాను…',example:'ఉదాహరణ',done:'నేటి లక్ష్యం పూర్తయింది!',unit:'యూనిట్',target:'రోజుకు పదాలు'},
hi:{learn:'सीखें',quiz:'क्विज़',progress:'प्रगति',listen:'सुनें',speak:'बोलें',next:'अगला',prev:'पीछे',goal:'आज का लक्ष्य',streak:'लगातार दिन',mastered:'सीखे गए शब्द',match:'उच्चारण मिलान',great:'शानदार! उच्चारण साफ़ है।',retry:'लगभग सही। फिर सुनकर दोबारा कोशिश करें।',nospeech:'इस ब्राउज़र में वॉइस इनपुट उपलब्ध नहीं है। शब्द टाइप करें।',check:'जाँचें',type:'शब्द टाइप करें',correct:'सही!',wrong:'सही नहीं। उत्तर:',pick:'अर्थ चुनें:',fill:'खाली जगह भरें',score:'स्कोर',start:'क्विज़ शुरू करें',again:'नया क्विज़',listening:'सुन रहा हूँ…',example:'उदाहरण',done:'आज का लक्ष्य पूरा!',unit:'इकाई',target:'प्रतिदिन शब्द'},
ta:{learn:'கற்க',quiz:'வினாடி வினா',progress:'முன்னேற்றம்',listen:'கேளுங்கள்',speak:'பேசுங்கள்',next:'அடுத்து',prev:'பின்',goal:'இன்றைய இலக்கு',streak:'தொடர் நாட்கள்',mastered:'கற்ற சொற்கள்',match:'உச்சரிப்பு பொருத்தம்',great:'அருமை! உச்சரிப்பு தெளிவு.',retry:'கிட்டத்தட்ட சரி. மீண்டும் கேட்டு முயலுங்கள்.',nospeech:'இந்த உலாவியில் குரல் உள்ளீடு இல்லை. சொல்லை தட்டச்சு செய்யுங்கள்.',check:'சரிபார்',type:'சொல்லை தட்டச்சு செய்க',correct:'சரி!',wrong:'தவறு. பதில்:',pick:'பொருளைத் தேர்ந்தெடுங்கள்:',fill:'இடைவெளியை நிரப்புங்கள்',score:'மதிப்பெண்',start:'வினாடி வினா தொடங்கு',again:'புதிய வினாடி வினா',listening:'கேட்கிறேன்…',example:'எடுத்துக்காட்டு',done:'இன்றைய இலக்கு முடிந்தது!',unit:'அலகு',target:'நாளுக்கு சொற்கள்'}
};
// [english, phonetic guide, Telugu, Hindi, Tamil, example sentence, unit]
const RAW=[
['Algorithm','AL-guh-rith-um','క్రమసూత్ర పద్ధతి','कलन विधि','படிமுறை','An algorithm lists the steps to solve a problem.',1],
['Variable','VAIR-ee-uh-bul','చరరాశి','चर','மாறி','A variable stores a value in memory.',1],
['Function','FUNK-shun','ప్రమేయం','फलन','சார்பு','A function returns a result.',1],
['Database','DAY-tuh-base','దత్తాంశ నిధి','आँकड़ा आधार','தரவுத்தளம்','The database stores every student record.',1],
['Network','NET-wurk','జాలం','संजाल','வலையமைப்பு','The network connects all computers in the lab.',1],
['Compiler','kum-PY-ler','అనువాదకం','संकलक','தொகுப்பி','The compiler translates code into machine language.',2],
['Debug','dee-BUG','దోషాలు సరిచేయు','त्रुटि सुधारना','பிழை நீக்கு','Always debug your code before submitting it.',2],
['Interface','IN-ter-face','అనుసంధానం','अंतरापृष्ठ','இடைமுகம்','A clean interface makes software easy to use.',2],
['Circuit','SUR-kit','వలయం','परिपथ','சுற்று','The circuit has a battery and a bulb.',3],
['Voltage','VOLE-tij','విద్యుత్ పీడనం','वोल्टता','மின்னழுத்தம்','Voltage pushes electric charge through a wire.',3],
['Current','KUR-unt','విద్యుత్ ప్రవాహం','धारा','மின்னோட்டம்','Current flows when the circuit is closed.',3],
['Resistance','ri-ZIS-tunce','నిరోధం','प्रतिरोध','மின்தடை','A thin wire has more resistance.',3],
['Force','FORS','బలం','बल','விசை','Force equals mass times acceleration.',3],
['Velocity','vuh-LOS-uh-tee','వేగం','वेग','திசைவேகம்','Velocity tells speed and direction together.',3],
['Efficiency','ih-FISH-un-see','సామర్థ్యం','दक्षता','செயல்திறன்','The new engine improves fuel efficiency.',3],
['Deadline','DED-line','గడువు','समय-सीमा','காலக்கெடு','The project deadline is next Friday.',4],
['Resume','REZ-oo-may','బయోడేటా','बायोडाटा','சுயவிவரக் குறிப்பு','Keep your resume to one page.',4],
['Interview','IN-ter-vyoo','ముఖాముఖి','साक्षात्कार','நேர்காணல்','I have a placement interview tomorrow.',4],
['Teamwork','TEEM-wurk','జట్టు కృషి','सामूहिक कार्य','குழுப்பணி','Good teamwork finishes the project faster.',4],
['Project','PROJ-ekt','ప్రాజెక్టు','परियोजना','திட்டம்','Our final year project is a smart meter.',4]
];
let WORDS=RAW.map(([en,ph,te,hi,ta,ex,u],id)=>({id,en,ph,te,hi,ta,ex,u}));
if(typeof module!=='undefined')module.exports={WORDS,RAW,UNITS,I18N};
