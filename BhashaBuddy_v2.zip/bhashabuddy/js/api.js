// ===== API client: loads words + syncs profile/scores; falls back to js/data.js and localStorage offline =====
const UID_KEY='bhashabuddy.uid';
function uid(){
  let id='';try{id=localStorage.getItem(UID_KEY)||''}catch(e){}
  if(!id){
    id=(crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+Math.random().toString(16).slice(2)).toLowerCase().replace(/[^a-z0-9-]/g,'').slice(0,40);
    try{localStorage.setItem(UID_KEY,id)}catch(e){}
  }
  return id;
}
const esc=s=>typeof s==='string'?s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])):s;
const sanitize=w=>Object.fromEntries(Object.entries(w).map(([k,v])=>[k,esc(v)]));   // server text is escaped before it reaches innerHTML
async function jfetch(u,opt){const r=await fetch(u,opt);if(!r.ok)throw new Error(r.status);return r.json()}
const post=(m,b)=>({method:m,headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
let syncTimer;
function pushProfile(){
  clearTimeout(syncTimer);
  syncTimer=setTimeout(()=>jfetch('/api/profile/'+uid(),post('PUT',{lang:S.lang,goal:S.goal,day:S.day,done:S.done,mastered:S.mastered,streak:S.streak,last:S.last})).catch(()=>{}),500);
}
function pushScore(wordId,score){jfetch('/api/scores',post('POST',{userId:uid(),wordId,score})).catch(()=>{})}
async function boot(){
  try{WORDS=(await jfetch('/api/words')).map(sanitize)}catch(e){}
  try{mergeProfile(await jfetch('/api/profile/'+uid()))}catch(e){}
  render();
}
