// Zero-dependency Node server: static files + JSON API with validation. Run: node server/server.js
const http=require('http'),fs=require('fs'),path=require('path');
const {WORDS}=require('../js/data.js');                       // single source of truth for vocabulary
const ROOT=path.join(__dirname,'..'),DB=process.env.DB_FILE||path.join(__dirname,'db.json');
const MIME={'.html':'text/html','.css':'text/css','.js':'text/javascript'};
const SEC={'X-Content-Type-Options':'nosniff','Permissions-Policy':'microphone=(self)',
  'Content-Security-Policy':"default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; connect-src 'self'"};
const LANG=['en','te','hi','ta'],ID=/^[a-z0-9-]{8,40}$/,DAY=/^\d{4}-\d{2}-\d{2}$/;

const ids=a=>Array.isArray(a)&&a.length<=WORDS.length&&a.every(n=>Number.isInteger(n)&&n>=0&&n<WORDS.length);
const validProfile=p=>!!p&&typeof p==='object'&&LANG.includes(p.lang)&&[3,5,10].includes(p.goal)&&ids(p.done)&&ids(p.mastered)
  &&Number.isInteger(p.streak)&&p.streak>=0&&p.streak<=3650&&typeof p.day==='string'&&(p.day===''||DAY.test(p.day))&&typeof p.last==='string'&&(p.last===''||DAY.test(p.last));
const validScore=b=>!!b&&typeof b.userId==='string'&&ID.test(b.userId)&&Number.isInteger(b.wordId)&&b.wordId>=0&&b.wordId<WORDS.length&&Number.isInteger(b.score)&&b.score>=0&&b.score<=100;

let db=null;
const read=()=>db||(db=(()=>{try{return JSON.parse(fs.readFileSync(DB,'utf8'))}catch(e){return{profiles:{},scores:{}}}})());
const write=()=>{const tmp=DB+'.tmp';fs.writeFileSync(tmp,JSON.stringify(db));fs.renameSync(tmp,DB)};
const send=(res,code,obj)=>{res.writeHead(code,{'Content-Type':'application/json'});res.end(JSON.stringify(obj))};
const body=req=>new Promise((ok,no)=>{let d='';req.on('data',c=>{d+=c;if(d.length>1e4){no(new Error('too large'));req.destroy()}});req.on('end',()=>{try{ok(JSON.parse(d||'{}'))}catch(e){no(e)}})});

async function api(req,res,url){
  const [kind,id]=url.pathname.split('/').slice(2);
  if(req.method==='GET'&&kind==='words'){const u=+url.searchParams.get('unit');return send(res,200,u?WORDS.filter(w=>w.u===u):WORDS)}
  if(kind==='profile'&&ID.test(id||'')){
    if(req.method==='GET'){const p=read().profiles[id];return p?send(res,200,p):send(res,404,{error:'not found'})}
    if(req.method==='PUT'){
      const p=await body(req);if(!validProfile(p))return send(res,400,{error:'invalid profile'});
      const c={lang:p.lang,goal:p.goal,day:p.day,done:p.done,mastered:p.mastered,streak:p.streak,last:p.last};
      read().profiles[id]=c;write();return send(res,200,c);
    }
  }
  if(req.method==='POST'&&kind==='scores'){
    const b=await body(req);if(!validScore(b))return send(res,400,{error:'invalid score'});
    const s=(read().scores[b.userId]??={});s[b.wordId]=Math.max(s[b.wordId]||0,b.score);write();return send(res,200,{best:s[b.wordId]});
  }
  send(res,404,{error:'not found'});
}
function serve(res,url){
  let p=decodeURIComponent(url.pathname);if(p.endsWith('/'))p+='index.html';
  const f=path.normalize(path.join(ROOT,p)),ext=path.extname(f);
  const ok=f.startsWith(ROOT+path.sep)&&MIME[ext]&&!/[\\/](server|tests|node_modules)[\\/]/.test(f);
  fs.readFile(f,(e,d)=>{if(!ok||e){res.writeHead(404);return res.end('Not found')}res.writeHead(200,{'Content-Type':MIME[ext]});res.end(d)});
}
const server=()=>http.createServer(async(req,res)=>{
  for(const[k,v]of Object.entries(SEC))res.setHeader(k,v);
  const url=new URL(req.url,'http://localhost');
  try{url.pathname.startsWith('/api/')?await api(req,res,url):serve(res,url)}catch(e){if(!res.headersSent)send(res,400,{error:'bad request'})}
});
module.exports={server,validProfile,validScore};
if(require.main===module){const port=process.env.PORT||3000;server().listen(port,()=>console.log('BhashaBuddy on http://localhost:'+port))}
